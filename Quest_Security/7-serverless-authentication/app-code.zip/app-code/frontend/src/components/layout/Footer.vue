<template>
        <footer class="page-footer orange">
            <span d="nav-mobile" class="white-text">&copy; 2022 Amazon Web Services</span>
        </footer>
</template>


<script>
export default {
    name: 'Footer',
    data(){
        return {

        }
    }
}
</script>
<style>
.page-footer{
    padding: 20px;
}
</style>